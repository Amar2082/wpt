const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const connection = require("./dbconnect");

const app = express();
const port = 3000;
app.use(bodyParser.json());
app.use(cors());


app.post('/course2', (req, res) => {
    const { cid, cname, fees, duration } = req.body;
    connection.query('INSERT INTO course2(cid,cname,fees,duration) VALUES(?,?,?,?)', [cid, cname, fees, duration], (err, result) => {
        if (err) {
            return res.status(500).send('internal server error');
        }
        res.send(req.body);
    });
});

app.get('/course2', (req, res) => {
    connection.query('SELECT * FROM course2', (err, result) => {
        if (err) {
            return res.status(500).send(err.message);
        }
        res.send(result);
    });
});

app.get('/course2/:cid', (req, res) => {
    const cid = req.params.cid;
    connection.query('SELECT * FROM course2 WHERE cid=?', [cid], (err, result) => {
        if (err) {
            return res.status(500).send('internal error while getting id');
        } if (result.length === 0) {
            return res.status(404).send({ message: 'course not found' });
        }
        res.send(result[0]);
    });
});

app.put('/course2/:cid', (req, res) => {
    const cid = req.params.cid;
    const { cname, fees, duration } = req.body;

    connection.query('UPDATE course2 SET cname=?,fees=?,duration=? WHERE cid=?', [cname, fees, duration, cid], (err, result) => {
        if (err) {
            return res.status(500).send("Internal server error while update");
        } if (result.affectedRows === 0) {
            return res.status(404).send({ message: 'course not found' });
        }
        res.send(req.body);
    });

});

app.delete('/course2/:cid', (req, res) => {
    const cid = req.params.cid;
    connection.query('DELETE FROM course2 WHERE cid=?', [cid], (err, result) => {
        if (err) {
            return res.status(500).send('Internal server error while deleting');
        } if (result.affectedRows === 0) {
            return res.status(404).send({ message: 'movie not found' });
        }
        res.send(result);
    });
});

app.listen(port);
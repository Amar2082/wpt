const mysql = require("mysql2");

var mysqlConnection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Shrey$heshi1745',
    database: 'cms',
    port: 3306
})

mysqlConnection.connect((err)=>{
    if(!err){
        console.log("connection start");
    }else{
        console.log(err);
    }
})

module.exports= mysqlConnection;
const url = "http://localhost:3000/course2";

document.addEventListener("DOMContentLoaded", () => {
    fetchdata();
});

function fetchdata() {
    fetch(url)
        .then(response => response.json())
        .then(data => {
            const tableBody = document.getElementById("table-body");
            tableBody.innerHTML = '';

            data.forEach(element => {
                const rows = document.createElement('tr');
                rows.innerHTML =
                    `<td>${element.cid}</td>
                <td>${element.cname}</td>
                <td>${element.fees}</td>
                <td>${element.duration}</td>
                `;
                tableBody.append(rows);

            });

        })
        .catch(error => console.error('error while fetching', error));
}

function deleteMovie(cid) {
    fetch(`${url}/${cid}`, {
        method: "DELETE"
    })
        .then(response => {
            if (response.ok) {
                fetchdata();
            } else {
                console.error('Error', response.statusText);
            }
        })
        .catch(error => console.log("error while deleting", error));
}